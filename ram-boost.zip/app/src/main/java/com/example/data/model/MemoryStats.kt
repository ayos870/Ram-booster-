package com.example.data.model

data class DeviceInfo(
    val manufacturer: String = "",
    val model: String = "",
    val deviceName: String = "",
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val isEmulator: Boolean = false,
    val kernelMemTotalKb: Long = 0L,
    val kernelMemFreeKb: Long = 0L,
    val kernelMemAvailKb: Long = 0L,
    val hardwareBoard: String = ""
) {
    val kernelTotalGb: Float get() = kernelMemTotalKb / (1024f * 1024f)
    fun formattedKernelTotal(): String = String.format("%.2f GB", kernelTotalGb)
}

data class MemoryStats(
    val totalRamBytes: Long = 0L,
    val availRamBytes: Long = 0L,
    val usedRamBytes: Long = 0L,
    val percentUsed: Int = 0,
    val isLowMemory: Boolean = false,
    val thresholdBytes: Long = 0L,
    val jvmHeapUsedBytes: Long = 0L,
    val jvmHeapMaxBytes: Long = 0L,
    val runningProcessesCount: Int = 0,
    val deviceInfo: DeviceInfo = DeviceInfo()
) {
    val totalRamGb: Float get() = totalRamBytes / (1024f * 1024f * 1024f)
    val usedRamGb: Float get() = usedRamBytes / (1024f * 1024f * 1024f)
    val availRamGb: Float get() = availRamBytes / (1024f * 1024f * 1024f)

    val totalRamMb: Long get() = totalRamBytes / (1024L * 1024L)
    val usedRamMb: Long get() = usedRamBytes / (1024L * 1024L)
    val availRamMb: Long get() = availRamBytes / (1024L * 1024L)

    fun formattedTotal(): String = String.format("%.2f GB", totalRamGb)
    fun formattedUsed(): String = String.format("%.2f GB", usedRamGb)
    fun formattedAvail(): String = String.format("%.2f GB", availRamGb)
}

data class ProcessItem(
    val pid: Int,
    val processName: String,
    val packageName: String,
    val appName: String,
    val memoryBytes: Long,
    val memoryMb: Float,
    val importance: Int,
    val importanceLabel: String,
    val isSystemApp: Boolean,
    val isWhitelisted: Boolean = false,
    val isSelected: Boolean = false
) {
    fun formattedMemory(): String {
        return if (memoryMb >= 1024f) {
            String.format("%.2f GB", memoryMb / 1024f)
        } else {
            String.format("%.1f MB", memoryMb)
        }
    }
}

data class BoostResult(
    val freedBytes: Long,
    val freedMb: Long,
    val closedTasksCount: Int,
    val beforePercent: Int,
    val afterPercent: Int,
    val timestamp: Long = System.currentTimeMillis()
)
