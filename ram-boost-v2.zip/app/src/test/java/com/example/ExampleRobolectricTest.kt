package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.MemoryStats
import com.example.manager.MemoryManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RAM Boost", appName)
    }

    @Test
    fun `memory stats calculation check`() {
        val stats = MemoryStats(
            totalRamBytes = 8L * 1024L * 1024L * 1024L,
            availRamBytes = 2L * 1024L * 1024L * 1024L,
            usedRamBytes = 6L * 1024L * 1024L * 1024L,
            percentUsed = 75
        )

        assertEquals("8.00 GB", stats.formattedTotal())
        assertEquals("6.00 GB", stats.formattedUsed())
        assertEquals("2.00 GB", stats.formattedAvail())
        assertEquals(75, stats.percentUsed)
    }

    @Test
    fun `memory manager initial retrieval`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val memoryManager = MemoryManager(context)
        val stats = memoryManager.getMemoryStats()
        assertNotNull(stats)
        assertTrue(stats.totalRamBytes >= 0L)
    }

    @Test
    fun `periodic auto clean preferences test`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = com.example.data.local.PreferencesManager(context)
        prefs.isPeriodicCleanEnabled = true
        prefs.periodicCleanIntervalMins = 3

        assertTrue(prefs.isPeriodicCleanEnabled)
        assertEquals(3, prefs.periodicCleanIntervalMins)
    }

    @Test
    fun `notification helper initialization test`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val helper = com.example.manager.NotificationHelper(context)
        assertNotNull(helper)
    }
}
