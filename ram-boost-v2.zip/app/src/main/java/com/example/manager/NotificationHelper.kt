package com.example.manager

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

class NotificationHelper(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_HIGH_RAM = "channel_high_ram_alerts"
        const val CHANNEL_AUTO_CLEANER = "channel_auto_cleaner_status"

        const val NOTIFICATION_ID_HIGH_RAM = 2001
        const val NOTIFICATION_ID_AUTO_CLEANER = 2002
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 1. High RAM Warning Channel (High importance, alert)
            val warningChannel = NotificationChannel(
                CHANNEL_HIGH_RAM,
                "High RAM Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when device memory usage exceeds your designated threshold"
                enableVibration(true)
            }

            // 2. Ongoing Auto-Cleaner Status Channel (Low importance, quiet in status bar)
            val autoCleanChannel = NotificationChannel(
                CHANNEL_AUTO_CLEANER,
                "Automatic RAM Cleaner Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active status bar indicator while periodic auto-cleaner is running"
                enableVibration(false)
            }

            notificationManager.createNotificationChannel(warningChannel)
            notificationManager.createNotificationChannel(autoCleanChannel)
        }
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * Posts a High RAM Warning notification when memory usage crosses threshold.
     */
    fun showHighRamWarning(
        percentUsed: Int,
        thresholdPercent: Int,
        usedFormatted: String
    ) {
        if (!hasNotificationPermission()) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_HIGH_RAM)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("⚠️ High RAM Warning: $percentUsed%")
            .setContentText("RAM usage reached $percentUsed% (Threshold: $thresholdPercent%). $usedFormatted occupied.")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("RAM usage is at $percentUsed%, exceeding your $thresholdPercent% threshold ($usedFormatted occupied). Tap to open RAM Boost and clear background processes.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_HIGH_RAM, notification)
    }

    /**
     * Updates or shows the ongoing status bar notification for the Automatic RAM Cleaner.
     */
    fun showAutoCleanerNotification(
        intervalMins: Int,
        countdownText: String
    ) {
        if (!hasNotificationPermission()) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_AUTO_CLEANER)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("RAM Auto-Cleaner Active")
            .setContentText("Cleans every ${intervalMins}m · Next clean in $countdownText")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_AUTO_CLEANER, notification)
    }

    /**
     * Cancels the ongoing status bar notification when the auto-cleaner is toggled off.
     */
    fun cancelAutoCleanerNotification() {
        notificationManager.cancel(NOTIFICATION_ID_AUTO_CLEANER)
    }

    fun cancelHighRamWarning() {
        notificationManager.cancel(NOTIFICATION_ID_HIGH_RAM)
    }
}
