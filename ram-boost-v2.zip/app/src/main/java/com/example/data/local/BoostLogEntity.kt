package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "boost_logs")
data class BoostLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long,
    val freedMb: Long,
    val beforePercent: Int,
    val afterPercent: Int,
    val closedTasksCount: Int,
    val triggerSource: String // "Manual Boost", "Threshold Auto-Clean", "Task Kill"
)
