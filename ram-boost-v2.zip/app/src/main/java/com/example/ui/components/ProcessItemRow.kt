package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProcessItem
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TechAlertRed
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechMintSecondary

@Composable
fun ProcessItemRow(
    item: ProcessItem,
    onToggleSelect: () -> Unit,
    onKill: () -> Unit,
    onToggleWhitelist: () -> Unit,
    modifier: Modifier = Modifier
) {
    val initial = item.appName.firstOrNull()?.uppercaseChar()?.toString() ?: "P"
    val avatarBgColor = when {
        item.isWhitelisted -> TechMintSecondary.copy(alpha = 0.2f)
        item.isSystemApp -> Color(0xFF64748B).copy(alpha = 0.2f)
        item.memoryMb > 150f -> TechAlertRed.copy(alpha = 0.2f)
        else -> TechCyanPrimary.copy(alpha = 0.2f)
    }

    val avatarTextColor = when {
        item.isWhitelisted -> TechMintSecondary
        item.isSystemApp -> Color(0xFFCBD5E1)
        item.memoryMb > 150f -> TechAlertRed
        else -> TechCyanPrimary
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurface)
            .border(
                width = 1.dp,
                color = if (item.isSelected) TechCyanPrimary.copy(alpha = 0.5f) else DarkSurfaceBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(enabled = !item.isWhitelisted && !item.isSystemApp) {
                onToggleSelect()
            }
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("process_item_${item.packageName}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Selection Checkbox
        if (!item.isWhitelisted && !item.isSystemApp) {
            Checkbox(
                checked = item.isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = TechCyanPrimary,
                    checkmarkColor = Color(0xFF0F172A),
                    uncheckedColor = Color(0xFF64748B)
                ),
                modifier = Modifier
                    .size(28.dp)
                    .testTag("checkbox_${item.packageName}")
            )
            Spacer(modifier = Modifier.width(8.dp))
        } else {
            // Protected Lock or System badge icon
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Protected",
                    tint = if (item.isWhitelisted) TechMintSecondary else Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        // App Icon / Initial Avatar
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(avatarBgColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initial,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = avatarTextColor
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // App Details
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = item.appName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }

            Text(
                text = item.packageName,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.padding(top = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Importance Badge
                Box(
                    modifier = Modifier
                        .background(DarkSurfaceElevated, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.importanceLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )
                }

                // RAM Memory badge
                Box(
                    modifier = Modifier
                        .background(
                            if (item.memoryMb > 150f) TechAlertRed.copy(alpha = 0.15f) else TechCyanPrimary.copy(alpha = 0.15f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.formattedMemory(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (item.memoryMb > 150f) TechAlertRed else TechCyanPrimary,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Whitelist Toggle button
        IconButton(
            onClick = onToggleWhitelist,
            modifier = Modifier
                .size(36.dp)
                .testTag("whitelist_btn_${item.packageName}")
        ) {
            Icon(
                imageVector = if (item.isWhitelisted) Icons.Filled.Shield else Icons.Outlined.Shield,
                contentDescription = if (item.isWhitelisted) "Protected (Tap to unprotect)" else "Protect task",
                tint = if (item.isWhitelisted) TechMintSecondary else Color(0xFF64748B),
                modifier = Modifier.size(20.dp)
            )
        }

        // Kill button
        if (!item.isWhitelisted && !item.isSystemApp) {
            IconButton(
                onClick = onKill,
                modifier = Modifier
                    .size(36.dp)
                    .background(TechAlertRed.copy(alpha = 0.15f), CircleShape)
                    .testTag("kill_btn_${item.packageName}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Kill Task",
                    tint = TechAlertRed,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
