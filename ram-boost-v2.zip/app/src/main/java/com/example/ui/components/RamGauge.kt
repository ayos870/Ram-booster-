package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TechAlertRed
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechMintSecondary
import com.example.ui.theme.TechWarningAmber
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RamGauge(
    percent: Int,
    thresholdPercent: Int,
    usedFormatted: String,
    totalFormatted: String,
    modifier: Modifier = Modifier,
    size: Dp = 230.dp
) {
    val animatedPercent by animateFloatAsState(
        targetValue = percent.toFloat().coerceIn(0f, 100f),
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "RamPercentAnim"
    )

    val isOverThreshold = percent >= thresholdPercent

    val gaugeColor by animateColorAsState(
        targetValue = when {
            percent >= thresholdPercent -> TechAlertRed
            percent >= 70 -> TechWarningAmber
            percent >= 50 -> TechCyanPrimary
            else -> TechMintSecondary
        },
        animationSpec = tween(500),
        label = "GaugeColorAnim"
    )

    Box(
        modifier = modifier
            .size(size)
            .testTag("ram_gauge_component"),
        contentAlignment = Alignment.Center
    ) {
        // Arc Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 16.dp.toPx()
            val canvasSize = this.size
            val diameter = canvasSize.minDimension - strokeWidth
            val topLeft = Offset((canvasSize.width - diameter) / 2, (canvasSize.height - diameter) / 2)
            val arcSize = Size(diameter, diameter)

            val startAngle = 135f
            val sweepAngle = 270f

            // Background Track
            drawArc(
                color = Color(0xFF1E293B),
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Dynamic Progress Arc
            val currentSweep = (animatedPercent / 100f) * sweepAngle
            if (currentSweep > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0.0f to TechMintSecondary,
                        0.5f to TechCyanPrimary,
                        0.8f to TechWarningAmber,
                        1.0f to TechAlertRed
                    ),
                    startAngle = startAngle,
                    sweepAngle = currentSweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            // Draw Marker for User's Threshold
            val thresholdAngleDeg = startAngle + (thresholdPercent / 100f) * sweepAngle
            val thresholdRad = Math.toRadians(thresholdAngleDeg.toDouble())
            val radius = diameter / 2
            val center = Offset(canvasSize.width / 2, canvasSize.height / 2)

            val markerInnerRadius = radius - strokeWidth / 2 - 4.dp.toPx()
            val markerOuterRadius = radius + strokeWidth / 2 + 4.dp.toPx()

            val p1 = Offset(
                x = (center.x + markerInnerRadius * cos(thresholdRad)).toFloat(),
                y = (center.y + markerInnerRadius * sin(thresholdRad)).toFloat()
            )
            val p2 = Offset(
                x = (center.x + markerOuterRadius * cos(thresholdRad)).toFloat(),
                y = (center.y + markerOuterRadius * sin(thresholdRad)).toFloat()
            )

            drawLine(
                color = Color.White,
                start = p1,
                end = p2,
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (isOverThreshold) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Threshold Exceeded",
                        tint = TechAlertRed,
                        modifier = Modifier.size(18.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Active",
                        tint = gaugeColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = if (isOverThreshold) "HIGH USAGE" else "RAM LOAD",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isOverThreshold) TechAlertRed else Color(0xFF94A3B8),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            Text(
                text = "${animatedPercent.toInt()}%",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )

            Text(
                text = "$usedFormatted / $totalFormatted",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            // User Threshold Indicator Pill
            Box(
                modifier = Modifier
                    .background(
                        color = if (isOverThreshold) TechAlertRed.copy(alpha = 0.2f) else Color(0xFF1E293B),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Threshold: $thresholdPercent%",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isOverThreshold) TechAlertRed else Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
